const test = require("node:test");
const assert = require("node:assert/strict");
const QUESTIONS = require("../questions.js");
const { CATEGORIES, validateQuestions } = require("../script.js");

test("모든 문항이 형식 검사를 통과한다", () => {
  assert.deepEqual(validateQuestions(QUESTIONS), []);
});

for (const c of CATEGORIES) {
  test(`${c}: 10문항`, () => {
    assert.equal(QUESTIONS.filter((q) => q.category === c).length, 10);
  });
}

test("최상급 표현이 든 문항은 문제에 기준과 시점이 있다 (휴리스틱)", () => {
  const superlative = /가장|최대|최소|최고|최장|최단|제일/;
  for (const q of QUESTIONS.filter((q) => superlative.test(q.question))) {
    assert.match(q.question, /기준/, q.id);
    assert.match(q.question, /\d{4}년|현재/, q.id);
  }
});

test("해설과 출처는 한 줄이다", () => {
  for (const q of QUESTIONS) assert.doesNotMatch(q.explanation + q.source, /\n/, q.id);
});
