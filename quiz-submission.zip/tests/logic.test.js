const test = require("node:test");
const assert = require("node:assert/strict");
const { seqRng, validQuestion, fakeQuestions, FakeStorage } = require("./helpers.js");
const {
  CATEGORIES, shuffle, validateQuestions, validateCounts,
  shuffleItem, buildRound, scoreFor, newGame, recordAnswer, nextQuestion, formatScore,
  SPEED_SECONDS, secondsLeft, useHint,
  createRetry, retryCurrent, retryAnswer, retryNext,
  BOARD_LIMIT, addRecord, normalizeNickname, todayString,
  NICKNAME_KEY, boardKey, getStorage, loadBoard, saveBoard, loadNickname, saveNickname, recordResult,
} = require("../script.js");

test("shuffle은 같은 원소의 새 배열을 돌려주고 입력을 바꾸지 않는다", () => {
  const input = [1, 2, 3, 4, 5];
  const out = shuffle(input);
  assert.notEqual(out, input);
  assert.deepEqual([...out].sort(), [1, 2, 3, 4, 5]);
  assert.deepEqual(input, [1, 2, 3, 4, 5]);
});

test("같은 rng 값이면 같은 결과가 나온다", () => {
  const a = shuffle([1, 2, 3, 4], seqRng([0.9, 0.1, 0.5]));
  const b = shuffle([1, 2, 3, 4], seqRng([0.9, 0.1, 0.5]));
  assert.deepEqual(a, b);
});

/* ===== Task 2: 문항 검증 ===== */

test("올바른 문항은 오류가 없다", () => {
  assert.deepEqual(validateQuestions([validQuestion()]), []);
});

const bad = {
  "보기 3개": { choices: ["a", "b", "c"] },
  "answer 4": { answer: 4 },
  "answer -1": { answer: -1 },
  "answer 소수": { answer: 1.5 },
  "source 빈 값": { source: "" },
  "source 공백": { source: "  " },
  "source 없음": { source: undefined },
  "문제 빈 값": { question: "" },
  "해설 빈 값": { explanation: "" },
  "보기 중복": { choices: ["a", "a", "c", "d"] },
  "카테고리 오타": { category: "역사" },
};
for (const [name, patch] of Object.entries(bad)) {
  test(`검사 실패: ${name}`, () => {
    const errors = validateQuestions([validQuestion(patch)]);
    assert.ok(errors.length > 0, "오류가 나와야 한다");
    assert.ok(errors[0].includes("t-01"), "오류 메시지에 id가 있어야 한다");
  });
}

test("id 중복을 잡는다", () => {
  assert.ok(validateQuestions([validQuestion(), validQuestion()]).length > 0);
});

function tenPerCategory() {
  const list = [];
  for (const c of CATEGORIES) {
    for (let i = 1; i <= 10; i++) list.push(validQuestion({ id: `${c}-${i}`, category: c }));
  }
  return list;
}

test("validateCounts: 카테고리당 10개면 정상", () => {
  assert.deepEqual(validateCounts(tenPerCategory()), []);
});

test("validateCounts: 한국사가 9개면 오류에 '한국사'가 들어 있다", () => {
  const errors = validateCounts(tenPerCategory().slice(1));
  assert.ok(errors.some((e) => e.includes("한국사")));
});

/* ===== Task 7: 판 상태와 점수 ===== */

const mixed = [...fakeQuestions("한국사", 12), ...fakeQuestions("과학", 5)];
const freshItems = () => buildRound(fakeQuestions("한국사", 10), "한국사", seqRng([0.5]));
const wrongIndex = (item) => (item.answerIndex + 1) % 4;

test("buildRound: 해당 카테고리 문항 10개, 중복 없음", () => {
  const items = buildRound(mixed, "한국사");
  assert.equal(items.length, 10);
  assert.ok(items.every((it) => it.id.startsWith("f-한국사-")));
  assert.equal(new Set(items.map((it) => it.id)).size, 10);
});

test("buildRound: 보기가 섞여도 정답 보기의 글자는 그대로다", () => {
  for (const seed of [[0.3, 0.8, 0.1], [0.99, 0.0, 0.5], [0.5]]) {
    for (const item of buildRound(mixed, "한국사", seqRng(seed))) {
      const orig = mixed.find((q) => q.id === item.id);
      assert.equal(item.choices[item.answerIndex], orig.choices[orig.answer]);
      assert.deepEqual([...item.choices].sort(), [...orig.choices].sort());
      assert.equal(item.explanation, orig.explanation);
      assert.equal(item.source, orig.source);
    }
  }
});

test("buildRound: 10개 미만이면 Error", () => {
  assert.throws(() => buildRound(fakeQuestions("한국사", 9), "한국사"));
});

test("shuffleItem: 새 객체를 돌려주고 원본을 바꾸지 않는다", () => {
  const item = freshItems()[0];
  const before = JSON.stringify(item);
  const out = shuffleItem(item, seqRng([0.1, 0.9]));
  assert.notEqual(out, item);
  assert.equal(JSON.stringify(item), before);
  assert.equal(out.choices[out.answerIndex], item.choices[item.answerIndex]);
});

test("연습: 정답이면 1점, 오답이면 0점", () => {
  assert.equal(scoreFor("practice", true, false), 1);
  assert.equal(scoreFor("practice", false, false), 0);
});

test("알 수 없는 모드는 Error", () => {
  assert.throws(() => scoreFor("x", true, false));
});

test("recordAnswer: 정답은 {correct:true, points:1}이고 score가 오른다", () => {
  const state = newGame(freshItems(), "practice");
  const item = state.items[0];
  const r = recordAnswer(state, item.answerIndex);
  assert.deepEqual(r, { correct: true, points: 1, answerIndex: item.answerIndex });
  assert.equal(state.score, 1);
  assert.equal(state.wrong.length, 0);
});

test("recordAnswer: 오답은 points 0이고 wrong에 그 문항이 들어간다", () => {
  const state = newGame(freshItems(), "practice");
  const item = state.items[0];
  const r = recordAnswer(state, wrongIndex(item));
  assert.deepEqual([r.correct, r.points], [false, 0]);
  assert.equal(state.score, 0);
  assert.deepEqual(state.wrong, [item]);
});

test("recordAnswer: null(시간 초과)은 오답으로 처리된다", () => {
  const state = newGame(freshItems(), "practice");
  const r = recordAnswer(state, null);
  assert.deepEqual([r.correct, r.points], [false, 0]);
  assert.equal(state.wrong.length, 1);
});

test("recordAnswer를 같은 문항에 두 번 호출하면 두 번째는 null이고 score가 변하지 않는다", () => {
  const state = newGame(freshItems(), "practice");
  const item = state.items[0];
  assert.ok(recordAnswer(state, item.answerIndex));
  assert.equal(recordAnswer(state, item.answerIndex), null);
  assert.equal(recordAnswer(state, wrongIndex(item)), null);
  assert.equal(state.score, 1);
  assert.equal(state.wrong.length, 0);
});

test("nextQuestion: 답하기 전에는 false이고 index가 변하지 않는다", () => {
  const state = newGame(freshItems(), "practice");
  assert.equal(nextQuestion(state), false);
  assert.equal(nextQuestion(state), false);
  assert.equal(state.index, 0);
});

test("nextQuestion: 답한 뒤에는 true이고 index가 1 오르며 answered가 false로 돌아온다", () => {
  const state = newGame(freshItems(), "practice");
  recordAnswer(state, state.items[0].answerIndex);
  assert.equal(nextQuestion(state), true);
  assert.equal(state.index, 1);
  assert.equal(state.answered, false);
  assert.equal(nextQuestion(state), false, "연타해도 한 문항을 건너뛰지 않는다");
  assert.equal(state.index, 1);
});

test("10문항을 끝내면 finished이고 이후 recordAnswer는 null이다", () => {
  const state = newGame(freshItems(), "practice");
  for (let i = 0; i < 10; i++) {
    recordAnswer(state, state.items[state.index].answerIndex);
    assert.equal(nextQuestion(state), true);
  }
  assert.equal(state.finished, true);
  assert.equal(recordAnswer(state, 0), null);
  assert.equal(nextQuestion(state), false);
});

test("전부 맞히면 score 10, wrong 비어 있음", () => {
  const state = newGame(freshItems(), "practice");
  for (let i = 0; i < 10; i++) {
    recordAnswer(state, state.items[state.index].answerIndex);
    nextQuestion(state);
  }
  assert.equal(state.score, 10);
  assert.deepEqual(state.wrong, []);
});

test("전부 틀리면 score 0, wrong 10개", () => {
  const state = newGame(freshItems(), "practice");
  for (let i = 0; i < 10; i++) {
    recordAnswer(state, wrongIndex(state.items[state.index]));
    nextQuestion(state);
  }
  assert.equal(state.score, 0);
  assert.equal(state.wrong.length, 10);
});

test("formatScore", () => {
  assert.equal(formatScore(8), "8");
  assert.equal(formatScore(7.5), "7.5");
  assert.equal(formatScore(0), "0");
});

/* ===== Task 10: 힌트·스피드 점수 규칙, 타이머 계산 ===== */

test("scoreFor 표", () => {
  assert.equal(scoreFor("speed", true, false), 1);
  assert.equal(scoreFor("speed", false, false), 0);
  assert.equal(scoreFor("hint", true, true), 0.5);
  assert.equal(scoreFor("hint", true, false), 1);
  assert.equal(scoreFor("hint", false, true), 0);
  assert.equal(scoreFor("hint", false, false), 0);
  assert.equal(scoreFor("practice", true, true), 1);
});

test("SPEED_SECONDS는 15다", () => assert.equal(SPEED_SECONDS, 15));

test("secondsLeft", () => {
  assert.equal(secondsLeft(0, 0), 15);
  assert.equal(secondsLeft(0, 1), 15);
  assert.equal(secondsLeft(0, 14001), 1);
  assert.equal(secondsLeft(0, 15000), 0);
  assert.equal(secondsLeft(0, 20000), 0);
  assert.equal(secondsLeft(5000, 11000), 9);
});

const oneItem = (answerIndex, id = "h") => ({
  id, question: "q", choices: ["a", "b", "c", "d"], answerIndex, explanation: "e", source: "s",
});

test("useHint: 정답을 빼고 오답 2개를 서로 다르게 고른다", () => {
  for (let answerIndex = 0; answerIndex < 4; answerIndex++) {
    for (const seed of [[0.0], [0.99], [0.3, 0.7, 0.1], [0.5]]) {
      const state = newGame([oneItem(answerIndex)], "hint");
      const hidden = useHint(state, seqRng(seed));
      assert.equal(hidden.length, 2);
      assert.notEqual(hidden[0], hidden[1]);
      assert.ok(!hidden.includes(answerIndex), "정답은 지워지지 않는다");
      assert.ok(hidden.every((i) => i >= 0 && i <= 3));
    }
  }
});

test("useHint: 연습·스피드 모드에서는 null", () => {
  for (const mode of ["practice", "speed"]) {
    assert.equal(useHint(newGame([oneItem(0)], mode)), null);
  }
});

test("useHint: 같은 문항에서 두 번째는 null이다", () => {
  const state = newGame([oneItem(0)], "hint");
  assert.ok(useHint(state));
  assert.equal(useHint(state), null);
});

test("useHint: 답한 뒤에는 null이다", () => {
  const state = newGame([oneItem(0)], "hint");
  recordAnswer(state, 0);
  assert.equal(useHint(state), null);
});

test("useHint: nextQuestion 뒤 새 문항에서는 다시 쓸 수 있다", () => {
  const state = newGame([oneItem(0, "a"), oneItem(1, "b")], "hint");
  assert.ok(useHint(state));
  recordAnswer(state, 0);
  nextQuestion(state);
  assert.ok(useHint(state));
});

test("힌트 모드 합산: 힌트 후 정답 0.5 + 힌트 없이 정답 1 + 힌트 후 오답 0 = 1.5", () => {
  const state = newGame([oneItem(0, "a"), oneItem(0, "b"), oneItem(0, "c")], "hint");
  useHint(state);
  assert.equal(recordAnswer(state, 0).points, 0.5);
  nextQuestion(state);
  assert.equal(recordAnswer(state, 0).points, 1);
  nextQuestion(state);
  useHint(state);
  assert.equal(recordAnswer(state, 3).points, 0);
  assert.equal(state.score, 1.5);
  assert.equal(formatScore(state.score), "1.5");
});

/* ===== Task 14: 틀린 문제 다시 풀기 로직 ===== */

const retryItems = () => [
  { ...oneItem(0, "r-a"), choices: ["a0", "a1", "a2", "a3"] },
  { ...oneItem(1, "r-b"), choices: ["b0", "b1", "b2", "b3"] },
  { ...oneItem(2, "r-c"), choices: ["c0", "c1", "c2", "c3"] },
];
const idsOf = (list) => list.map((it) => it.id).sort();
// 현재 문항에 맞게(또는 틀리게) 답하고 다음으로 간다
function retryStep(r, correct) {
  const item = retryCurrent(r);
  const choice = correct ? item.answerIndex : (item.answerIndex + 1) % 4;
  const result = retryAnswer(r, choice);
  retryNext(r);
  return result;
}

test("createRetry: 틀린 문항들만 들어 있고 입력을 바꾸지 않는다", () => {
  const wrong = retryItems();
  const before = JSON.stringify(wrong);
  const r = createRetry(wrong, seqRng([0.3, 0.7]));
  assert.deepEqual(idsOf(r.pass), ["r-a", "r-b", "r-c"]);
  assert.equal(JSON.stringify(wrong), before);
  assert.equal(r.done, false);
});

test("정답이면 다음 바퀴에 나오지 않고, 오답이면 다음 바퀴에 다시 나온다", () => {
  const r = createRetry(retryItems(), seqRng([0.5]));
  const firstPass = r.pass.map((it) => it.id);
  retryStep(r, true);   // 첫 문항만 맞힘
  retryStep(r, false);
  retryStep(r, false);
  assert.equal(r.done, false);
  assert.deepEqual(idsOf(r.pass), firstPass.slice(1).sort());
  assert.equal(r.pos, 0);
});

test("모두 맞히면 done이 되고 retryCurrent는 null이다", () => {
  const r = createRetry(retryItems());
  for (let i = 0; i < 3; i++) retryStep(r, true);
  assert.equal(r.done, true);
  assert.equal(retryCurrent(r), null);
  assert.equal(retryAnswer(r, 0), null);
  assert.equal(retryNext(r), false);
});

test("틀리는 문항은 맞힐 때까지 계속 돌아온다", () => {
  const r = createRetry(retryItems(), seqRng([0.5]));
  const stubborn = r.pass[0].id;
  for (let round = 0; round < 3 && !r.done; round++) {
    const passIds = r.pass.map((it) => it.id);
    for (let i = 0; i < passIds.length; i++) retryStep(r, retryCurrent(r).id !== stubborn);
    if (!r.done) assert.ok(r.pass.some((it) => it.id === stubborn));
  }
  assert.equal(r.done, false);
});

test("한 문항을 두 번 연속 답해도 두 번째는 null이다 (이중 입력)", () => {
  const r = createRetry(retryItems());
  const item = retryCurrent(r);
  assert.equal(retryAnswer(r, (item.answerIndex + 1) % 4).correct, false);
  assert.equal(retryAnswer(r, item.answerIndex), null);
  assert.equal(r.missed.length, 1);
});

test("retryNext: 답하기 전에는 false이고 pos가 변하지 않는다", () => {
  const r = createRetry(retryItems());
  assert.equal(retryNext(r), false);
  assert.equal(retryNext(r), false);
  assert.equal(r.pos, 0);
});

test("새 바퀴가 되면 보기가 다시 섞여도 정답 보기의 글자는 그대로다", () => {
  const originals = Object.fromEntries(retryItems().map((it) => [it.id, it.choices[it.answerIndex]]));
  const r = createRetry(retryItems(), seqRng([0.9, 0.1, 0.6, 0.2]));
  for (let i = 0; i < 3; i++) retryStep(r, false);
  for (const item of r.pass) assert.equal(item.choices[item.answerIndex], originals[item.id]);
});

test("틀린 문항이 0개면 곧바로 done이다", () => {
  const r = createRetry([]);
  assert.equal(r.done, true);
  assert.equal(retryCurrent(r), null);
});

/* ===== Task 16: 순위표 기록 로직 ===== */

const rec = (score, nickname = "n", date = "2026-10-10") => ({ nickname, score, date });
const scores = (table) => table.map((r) => r.score);

test("BOARD_LIMIT는 10이다", () => assert.equal(BOARD_LIMIT, 10));

test("addRecord: 빈 표에 넣으면 rank 1", () => {
  const out = addRecord([], rec(7));
  assert.equal(out.rank, 1);
  assert.deepEqual(scores(out.table), [7]);
});

test("addRecord: 점수 내림차순", () => {
  let table = [];
  for (const sc of [7, 9, 8]) table = addRecord(table, rec(sc)).table;
  assert.deepEqual(scores(table), [9, 8, 7]);
});

test("addRecord: 동점이면 새 기록이 위", () => {
  const out = addRecord([rec(8, "old")], rec(8, "new"));
  assert.equal(out.rank, 1);
  assert.equal(out.table[0].nickname, "new");
  assert.equal(out.table[1].nickname, "old");
});

test("addRecord: 10건이 차면 맨 아래가 밀려난다", () => {
  const full = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1].map((n) => rec(n));
  const out = addRecord(full, rec(5, "new"));
  assert.equal(out.table.length, 10);
  assert.equal(out.rank, 6, "기존 5점 바로 위");
  assert.deepEqual(scores(out.table), [10, 9, 8, 7, 6, 5, 5, 4, 3, 2]);
});

test("addRecord: 10건이 차고 모두 6점 이상이면 5점은 rank null이고 표가 그대로다", () => {
  const full = [10, 10, 9, 9, 8, 8, 7, 7, 6, 6].map((n) => rec(n));
  const out = addRecord(full, rec(5));
  assert.equal(out.rank, null);
  assert.deepEqual(out.table, full);
});

test("addRecord: 꼴찌와 동점이면 새 기록이 들어가고 옛 꼴찌가 밀려난다", () => {
  const full = [10, 9, 8, 7, 6, 5.5, 5.5, 5.5, 5.5, 5].map((n, i) => rec(n, `old${i}`));
  const out = addRecord(full, rec(5, "new"));
  assert.equal(out.rank, 10);
  assert.equal(out.table.length, 10);
  assert.equal(out.table[9].nickname, "new");
  assert.ok(!out.table.some((r) => r.nickname === "old9"), "옛 꼴찌는 밀려난다");
});

test("addRecord: 0.5점 단위 정렬", () => {
  let table = [];
  for (const sc of [7.5, 7, 8]) table = addRecord(table, rec(sc)).table;
  assert.deepEqual(scores(table), [8, 7.5, 7]);
});

test("addRecord: 입력 표를 바꾸지 않는다", () => {
  const table = [rec(9), rec(5)];
  const before = JSON.stringify(table);
  addRecord(table, rec(7));
  addRecord(table, rec(1));
  assert.equal(JSON.stringify(table), before);
});

test("normalizeNickname", () => {
  assert.equal(normalizeNickname("  민수  "), "민수");
  assert.equal(normalizeNickname(""), null);
  assert.equal(normalizeNickname("   "), null);
  assert.equal(normalizeNickname("가".repeat(12)), "가".repeat(12));
  assert.equal(normalizeNickname("가".repeat(13)), null);
  assert.equal(normalizeNickname(123), null);
  assert.equal(normalizeNickname(null), null);
  assert.equal(normalizeNickname("<b>x</b>"), "<b>x</b>");
  assert.equal(normalizeNickname("😀".repeat(12)), "😀".repeat(12), "이모지도 글자 수로 센다");
});

test("todayString", () => {
  assert.equal(todayString(new Date(2026, 9, 10)), "2026-10-10");
  assert.equal(todayString(new Date(2026, 0, 5)), "2026-01-05");
});

/* ===== Task 17: 저장소 계층 ===== */

test("boardKey와 닉네임 키", () => {
  assert.equal(boardKey("speed", "한국사"), "quiz:v1:board:speed:한국사");
  assert.equal(boardKey("hint", "예술과 문화"), "quiz:v1:board:hint:예술과 문화");
  assert.equal(NICKNAME_KEY, "quiz:v1:nickname");
});

test("loadBoard: 값이 없으면 []", () => {
  assert.deepEqual(loadBoard(new FakeStorage(), "speed", "과학"), []);
});

test("loadBoard: 깨진 JSON이면 []", () => {
  const st = new FakeStorage();
  st.setItem(boardKey("speed", "과학"), "{{{");
  assert.deepEqual(loadBoard(st, "speed", "과학"), []);
});

test("loadBoard: 배열이 아닌 JSON이면 []", () => {
  const st = new FakeStorage();
  st.setItem(boardKey("speed", "과학"), '{"a":1}');
  assert.deepEqual(loadBoard(st, "speed", "과학"), []);
});

test("loadBoard: 형식이 틀린 항목은 걸러낸다", () => {
  const st = new FakeStorage();
  const good = rec(8, "민수");
  st.setItem(boardKey("hint", "과학"), JSON.stringify([good, { nickname: "x", score: "9", date: "d" }, { score: 5, date: "d" }, null, 3]));
  assert.deepEqual(loadBoard(st, "hint", "과학"), [good]);
});

test("loadBoard: 읽기가 throw해도 []이고 예외가 밖으로 나오지 않는다", () => {
  assert.deepEqual(loadBoard(new FakeStorage({ throwOnGet: true }), "speed", "과학"), []);
});

test("storage가 null이면 load는 []/null, save는 false", () => {
  assert.deepEqual(loadBoard(null, "speed", "과학"), []);
  assert.equal(loadNickname(null), null);
  assert.equal(saveBoard(null, "speed", "과학", []), false);
  assert.equal(saveNickname(null, "민수"), false);
});

test("setItem이 throw하면 save는 false이고 예외가 밖으로 나오지 않는다", () => {
  const st = new FakeStorage({ throwOnSet: true });
  assert.equal(saveBoard(st, "speed", "과학", [rec(1)]), false);
  assert.equal(saveNickname(st, "민수"), false);
});

test("닉네임 저장과 불러오기", () => {
  const st = new FakeStorage();
  assert.equal(loadNickname(st), null);
  assert.equal(saveNickname(st, "민수"), true);
  assert.equal(loadNickname(st), "민수");
});

test("saveNickname: 규칙에 맞지 않는 닉네임은 저장하지 않는다", () => {
  const st = new FakeStorage();
  assert.equal(saveNickname(st, "  "), false);
  assert.equal(saveNickname(st, "가".repeat(13)), false);
  assert.equal(loadNickname(st), null);
});

test("loadNickname: 저장된 값이 규칙에 어긋나면 null", () => {
  const st = new FakeStorage();
  st.setItem(NICKNAME_KEY, "가".repeat(40));
  assert.equal(loadNickname(st), null);
});

test("recordResult: 정상이면 ranked와 rank, 저장된다", () => {
  const st = new FakeStorage();
  const out = recordResult(st, "speed", "한국사", rec(8, "민수"));
  assert.deepEqual(out, { status: "ranked", rank: 1 });
  assert.deepEqual(loadBoard(st, "speed", "한국사"), [rec(8, "민수")]);
  assert.equal(recordResult(st, "speed", "한국사", rec(9, "영희")).rank, 1);
  assert.deepEqual(scores(loadBoard(st, "speed", "한국사")), [9, 8]);
});

test("recordResult: 10건이 차고 낮은 점수면 outside이고 저장 내용이 그대로다", () => {
  const st = new FakeStorage();
  for (let i = 0; i < 10; i++) recordResult(st, "hint", "과학", rec(6 + (i % 4) * 0.5));
  const before = st.getItem(boardKey("hint", "과학"));
  const out = recordResult(st, "hint", "과학", rec(1));
  assert.deepEqual(out, { status: "outside", rank: null });
  assert.equal(st.getItem(boardKey("hint", "과학")), before);
});

test("recordResult: storage null 또는 저장 실패면 unavailable", () => {
  assert.deepEqual(recordResult(null, "speed", "과학", rec(5)), { status: "unavailable", rank: null });
  assert.deepEqual(recordResult(new FakeStorage({ throwOnSet: true }), "speed", "과학", rec(5)), { status: "unavailable", rank: null });
  assert.deepEqual(recordResult(new FakeStorage({ throwOnGet: true }), "speed", "과학", rec(5)).status, "unavailable");
});

test("recordResult: 연습 모드는 기록하지 않는다(Error)", () => {
  assert.throws(() => recordResult(new FakeStorage(), "practice", "과학", rec(5)));
});

test("표가 모드·카테고리별로 격리된다", () => {
  const st = new FakeStorage();
  recordResult(st, "speed", "한국사", rec(8));
  assert.deepEqual(loadBoard(st, "hint", "한국사"), []);
  assert.deepEqual(loadBoard(st, "speed", "과학"), []);
  assert.equal(loadBoard(st, "speed", "한국사").length, 1);
});

test("getStorage: window가 없는 환경(Node)에서는 null", () => {
  assert.equal(getStorage(), null);
});
