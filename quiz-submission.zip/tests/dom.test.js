const test = require("node:test");
const assert = require("node:assert/strict");
const { loadApp, makeClock } = require("./fake-dom.js");
const { FakeStorage } = require("./helpers.js");
const { CATEGORIES } = require("../script.js");

const visibleScreens = (document) =>
  document.querySelectorAll(".screen").filter((s) => !s.hidden).map((s) => s.id);

test("로딩하면 카테고리 선택 화면만 보이고 버튼 4개와 안내 문구가 있다", () => {
  const { document } = loadApp();
  assert.deepEqual(visibleScreens(document), ["screen-categories"]);
  const buttons = document.getElementById("category-list").kids;
  assert.deepEqual(buttons.map((b) => b.textContent), CATEGORIES);
  assert.equal(document.getElementById("error-banner").hidden, true);
});

test("데이터에 오류가 있으면 오류 배너를 보여 주고 퀴즈를 시작하지 않는다", () => {
  const { document } = loadApp({ mutateQuestions: (q) => { q[0].source = ""; } });
  const banner = document.getElementById("error-banner");
  assert.equal(banner.hidden, false);
  assert.match(banner.textContent, /kh-01/);
  assert.deepEqual(visibleScreens(document), []);
});

/* ===== Task 9: 문제 진행, 해설, 결과 ===== */

const choiceButtons = (document) => document.getElementById("choices").kids;
const clickCategory = (app, name) =>
  app.document.getElementById("category-list").kids.find((b) => b.textContent === name).click();
const modeButton = (app, label) =>
  app.document.getElementById("mode-list").kids.find((b) => b.kids[0].textContent === label);
const startWithMode = (app, category, mode) => {
  clickCategory(app, category);
  modeButton(app, mode).click();
};
const startCategory = (app, name) => startWithMode(app, name, "연습");
const correctIndex = (app) => app.run("app.state.items[app.state.index].answerIndex");
const wrongIndexNow = (app) => (correctIndex(app) + 1) % 4;
const clickNext = (app) => app.document.getElementById("btn-next").click();

function playRound(app, pick) {
  for (let i = 0; i < 10; i++) {
    choiceButtons(app.document)[pick(app)].click();
    clickNext(app);
  }
}

test("카테고리를 누르면 1 / 10 문제와 보기 4개가 나온다", () => {
  const app = loadApp();
  startCategory(app, "과학");
  const d = app.document;
  assert.deepEqual(visibleScreens(d), ["screen-quiz"]);
  assert.equal(d.getElementById("progress").textContent, "1 / 10");
  assert.ok(d.getElementById("question").textContent.length > 0);
  assert.equal(choiceButtons(d).length, 4);
  assert.equal(d.getElementById("explanation").hidden, true);
  assert.equal(d.getElementById("btn-next").hidden, true);
});

test("보기를 고르면 ✓/✗, 정답, 해설, 출처가 보이고 보기가 잠긴다", () => {
  const app = loadApp();
  startCategory(app, "한국사");
  const d = app.document;
  const right = correctIndex(app);
  const wrong = wrongIndexNow(app);
  choiceButtons(d)[wrong].click();
  const buttons = choiceButtons(d);
  assert.ok(buttons.every((b) => b.disabled), "모든 보기가 잠긴다");
  assert.match(buttons[right].textContent, /✓/);
  assert.match(buttons[wrong].textContent, /✗/);
  assert.ok(buttons[right].classList.contains("is-correct"));
  assert.ok(buttons[wrong].classList.contains("is-wrong"));
  const exp = d.getElementById("explanation");
  assert.equal(exp.hidden, false);
  assert.match(exp.textContent, /오답/);
  assert.match(exp.textContent, /출처: /);
  assert.equal(d.getElementById("btn-next").hidden, false);
  assert.equal(app.run("app.state.score"), 0);
});

test("이미 답한 문항에서 다른 보기를 눌러도 점수가 바뀌지 않는다", () => {
  const app = loadApp();
  startCategory(app, "세계지리");
  const right = correctIndex(app);
  choiceButtons(app.document)[right].click();
  app.run("onChoose(" + wrongIndexNow(app) + ")");
  assert.equal(app.run("app.state.score"), 1);
  assert.equal(app.run("app.state.wrong.length"), 0);
});

test("[다음]을 연타해도 한 문항만 넘어간다", () => {
  const app = loadApp();
  startCategory(app, "과학");
  choiceButtons(app.document)[correctIndex(app)].click();
  clickNext(app);
  app.run("onNext(); onNext();");
  assert.equal(app.document.getElementById("progress").textContent, "2 / 10");
});

test("10문제를 전부 맞히면 결과에 10 / 10과 안내 문구가 나온다", () => {
  const app = loadApp();
  startCategory(app, "예술과 문화");
  playRound(app, correctIndex);
  const d = app.document;
  assert.deepEqual(visibleScreens(d), ["screen-result"]);
  assert.equal(d.getElementById("score").textContent, "10 / 10");
  assert.equal(d.getElementById("result-notice").textContent, "순위표에 기록되지 않음");
});

test("10문제를 전부 틀리면 0 / 10이 나온다", () => {
  const app = loadApp();
  startCategory(app, "한국사");
  playRound(app, wrongIndexNow);
  assert.equal(app.document.getElementById("score").textContent, "0 / 10");
});

test("마지막 문제의 [다음] 버튼은 '결과 보기'다", () => {
  const app = loadApp();
  startCategory(app, "과학");
  for (let i = 0; i < 9; i++) {
    choiceButtons(app.document)[correctIndex(app)].click();
    clickNext(app);
  }
  choiceButtons(app.document)[correctIndex(app)].click();
  assert.equal(app.document.getElementById("btn-next").textContent, "결과 보기");
});

test("[그만두기]는 카테고리 선택으로 돌아가고 새 판은 1번부터 시작한다", () => {
  const app = loadApp();
  startCategory(app, "과학");
  choiceButtons(app.document)[correctIndex(app)].click();
  clickNext(app);
  app.document.getElementById("btn-quit").click();
  assert.deepEqual(visibleScreens(app.document), ["screen-categories"]);
  startCategory(app, "과학");
  assert.equal(app.document.getElementById("progress").textContent, "1 / 10");
});

test("결과 화면의 [처음으로]는 카테고리 선택으로 돌아간다", () => {
  const app = loadApp();
  startCategory(app, "과학");
  playRound(app, correctIndex);
  app.document.getElementById("btn-home").click();
  assert.deepEqual(visibleScreens(app.document), ["screen-categories"]);
});

test("같은 카테고리를 두 번 풀면 문제 순서가 같지 않다(무작위)", () => {
  const first = [];
  const second = [];
  for (const out of [first, second]) {
    const app = loadApp();
    startCategory(app, "한국사");
    out.push(...app.run("app.state.items.map((it) => it.id)"));
  }
  assert.notDeepEqual(first, second);
});

/* ===== 최종 리뷰에서 추가 ===== */

test("questions.js를 불러오지 못하면 빈 화면 대신 안내 배너를 보여 준다", () => {
  const { document } = loadApp({ skipQuestions: true });
  const banner = document.getElementById("error-banner");
  assert.equal(banner.hidden, false);
  assert.match(banner.textContent, /questions\.js/);
  assert.deepEqual(visibleScreens(document), []);
});


/* ===== Task 11: 카테고리 다음 모드 선택 화면, 학번·이름 ===== */

test("카테고리를 고르면 모드 선택 화면에 연습·스피드·힌트 3개가 나온다", () => {
  const app = loadApp();
  clickCategory(app, "한국사");
  assert.deepEqual(visibleScreens(app.document), ["screen-mode"]);
  const names = app.document.getElementById("mode-list").kids.map((b) => b.kids[0].textContent);
  assert.deepEqual(names, ["연습", "스피드", "힌트"]);
});

test("'순위표에 기록되지 않음'은 연습 항목에만 있다", () => {
  const app = loadApp();
  clickCategory(app, "과학");
  assert.match(modeButton(app, "연습").textContent, /순위표에 기록되지 않음/);
  assert.doesNotMatch(modeButton(app, "스피드").textContent, /순위표에 기록되지 않음/);
  assert.doesNotMatch(modeButton(app, "힌트").textContent, /순위표에 기록되지 않음/);
});

test("[뒤로]는 카테고리 선택으로 돌아간다", () => {
  const app = loadApp();
  clickCategory(app, "과학");
  app.document.getElementById("btn-mode-back").click();
  assert.deepEqual(visibleScreens(app.document), ["screen-categories"]);
});

test("모드를 고르면 그 카테고리·모드로 판이 시작된다", () => {
  for (const [label, mode] of [["연습", "practice"], ["스피드", "speed"], ["힌트", "hint"]]) {
    const app = loadApp({ clock: makeClock() }); // 스피드 모드가 진짜 타이머를 돌리지 않게 가짜 시계를 쓴다
    startWithMode(app, "세계지리", label);
    assert.deepEqual(visibleScreens(app.document), ["screen-quiz"]);
    assert.equal(app.run("app.state.mode"), mode);
    assert.equal(app.run("app.category"), "세계지리");
    assert.equal(app.document.getElementById("progress").textContent, "1 / 10");
  }
});

test("모든 화면 아래에 학번·이름 자리가 있고 비어 있지 않다", () => {
  const app = loadApp();
  assert.ok(app.document.getElementById("student-info").textContent.trim().length > 0);
});


/* ===== Task 12: 스피드 모드 15초 타이머 ===== */

function speedApp(category = "과학") {
  const clock = makeClock();
  const app = loadApp({ clock });
  startWithMode(app, category, "스피드");
  return { app, clock, d: app.document, timerText: () => app.document.getElementById("timer").textContent };
}

test("스피드: 문제가 나오면 남은 시간이 15초로 시작하고 타이머가 보인다", () => {
  const { d, timerText } = speedApp();
  assert.equal(d.getElementById("timer").hidden, false);
  assert.equal(timerText(), "남은 시간 15초");
});

test("스피드: 시간이 지나면 남은 시간이 줄어든다", () => {
  const { clock, timerText } = speedApp();
  clock.advance(3000);
  assert.equal(timerText(), "남은 시간 12초");
  clock.advance(7000);
  assert.equal(timerText(), "남은 시간 5초");
});

test("스피드: 0초가 되면 시간 초과로 오답 처리되고 정답과 해설이 나온다", () => {
  const { app, clock, d } = speedApp();
  const right = correctIndex(app);
  clock.advance(15000);
  assert.equal(d.getElementById("timer").textContent, "남은 시간 0초");
  const exp = d.getElementById("explanation");
  assert.equal(exp.hidden, false);
  assert.match(exp.textContent, /시간 초과/);
  assert.match(exp.textContent, /출처: /);
  assert.equal(app.run("app.state.score"), 0);
  assert.equal(app.run("app.state.wrong.length"), 1);
  const buttons = choiceButtons(d);
  assert.ok(buttons.every((b) => b.disabled));
  assert.match(buttons[right].textContent, /✓/);
  assert.equal(d.getElementById("btn-next").hidden, false);
});

test("스피드: 해설이 나오면 타이머가 멈춘다", () => {
  const { clock, timerText } = speedApp();
  clock.advance(15000);
  const shown = timerText();
  clock.advance(30000);
  assert.equal(timerText(), shown);
  assert.equal(clock.timers.length, 0, "남아 있는 인터벌이 없다");
});

test("스피드: [다음]을 누르면 다음 문제가 15초부터 다시 센다", () => {
  const { app, clock, timerText } = speedApp();
  clock.advance(15000);
  clickNext(app);
  assert.equal(timerText(), "남은 시간 15초");
  clock.advance(5000);
  assert.equal(timerText(), "남은 시간 10초");
});

test("스피드: 제한 시간 안에 맞히면 1점이고 타이머가 멈춘다", () => {
  const { app, clock, d } = speedApp();
  clock.advance(4000);
  choiceButtons(d)[correctIndex(app)].click();
  assert.equal(app.run("app.state.score"), 1);
  assert.equal(clock.timers.length, 0);
});

test("스피드: 마감 직전에 누른 정답은 이후 타이머와 겹쳐도 한 번만 채점된다", () => {
  const { app, clock, d } = speedApp();
  clock.advance(14900);
  choiceButtons(d)[correctIndex(app)].click();
  clock.advance(5000);
  assert.equal(app.run("app.state.score"), 1);
  assert.equal(app.run("app.state.wrong.length"), 0);
});

test("스피드: 시간 초과 직후에 누른 보기는 무시된다", () => {
  const { app, clock } = speedApp();
  clock.advance(15000);
  app.run("onChoose(" + correctIndex(app) + ")");
  assert.equal(app.run("app.state.score"), 0);
  assert.equal(app.run("app.state.wrong.length"), 1);
});

test("스피드: 탭이 오래 멈췄다 돌아와도 실제 경과 시간으로 시간 초과가 된다", () => {
  const { app, clock } = speedApp();
  clock.now += 20000;
  clock.advance(200);
  assert.match(app.document.getElementById("explanation").textContent, /시간 초과/);
});

test("연습·힌트 모드에서는 타이머가 없다", () => {
  for (const mode of ["연습", "힌트"]) {
    const clock = makeClock();
    const app = loadApp({ clock });
    startWithMode(app, "한국사", mode);
    assert.equal(app.document.getElementById("timer").hidden, true);
    assert.equal(clock.timers.length, 0);
  }
});

test("스피드: [그만두기]와 결과 화면에서 타이머가 멈춘다", () => {
  const a = speedApp();
  a.app.document.getElementById("btn-quit").click();
  assert.equal(a.clock.timers.length, 0);

  const b = speedApp();
  for (let i = 0; i < 10; i++) {
    choiceButtons(b.app.document)[correctIndex(b.app)].click();
    clickNext(b.app);
  }
  assert.deepEqual(visibleScreens(b.app.document), ["screen-result"]);
  assert.equal(b.clock.timers.length, 0);
  assert.equal(b.app.document.getElementById("score").textContent, "10 / 10");
});

test("스피드 모드 결과에는 '순위표에 기록되지 않음'이 없다", () => {
  const { app, clock } = speedApp();
  for (let i = 0; i < 10; i++) {
    clock.advance(15000);
    clickNext(app);
  }
  assert.equal(app.document.getElementById("score").textContent, "0 / 10");
  assert.equal(app.document.getElementById("result-notice").textContent, "");
});

/* ===== Task 13: 힌트 모드 화면 ===== */

function hintApp(category = "과학") {
  const app = loadApp();
  startWithMode(app, category, "힌트");
  return { app, d: app.document };
}
const shownChoices = (d) => choiceButtons(d).filter((b) => !b.hidden);

test("힌트: 힌트 모드에서만 [힌트] 버튼이 보인다", () => {
  assert.equal(hintApp().d.getElementById("btn-hint").hidden, false);
  for (const mode of ["연습", "스피드"]) {
    const app = loadApp({ clock: makeClock() });
    startWithMode(app, "과학", mode);
    assert.equal(app.document.getElementById("btn-hint").hidden, true);
  }
});

test("힌트: 누르면 오답 보기 2개가 지워지고 정답은 남는다", () => {
  const { app, d } = hintApp();
  const right = correctIndex(app);
  d.getElementById("btn-hint").click();
  const shown = shownChoices(d);
  assert.equal(shown.length, 2);
  assert.ok(!choiceButtons(d)[right].hidden, "정답 보기는 남아 있다");
});

test("힌트: 한 문항에서 한 번만 쓸 수 있다", () => {
  const { app, d } = hintApp();
  d.getElementById("btn-hint").click();
  assert.equal(d.getElementById("btn-hint").disabled, true);
  app.run("onHint()");
  assert.equal(shownChoices(d).length, 2);
});

test("힌트: 보기를 고른 뒤에는 쓸 수 없다", () => {
  const { app, d } = hintApp();
  choiceButtons(d)[correctIndex(app)].click();
  assert.equal(d.getElementById("btn-hint").disabled, true);
  app.run("onHint()");
  assert.equal(shownChoices(d).length, 4);
});

test("힌트: 힌트를 쓰고 맞히면 0.5점, 안 쓰고 맞히면 1점, 쓰고 틀리면 0점이 해설에 나온다", () => {
  const a = hintApp();
  a.d.getElementById("btn-hint").click();
  choiceButtons(a.d)[correctIndex(a.app)].click();
  assert.match(a.d.getElementById("explanation").textContent, /획득 점수: 0\.5점/);
  assert.equal(a.app.run("app.state.score"), 0.5);

  const b = hintApp();
  choiceButtons(b.d)[correctIndex(b.app)].click();
  assert.match(b.d.getElementById("explanation").textContent, /획득 점수: 1점/);

  const c = hintApp();
  c.d.getElementById("btn-hint").click();
  const wrongShown = shownChoices(c.d).findIndex((btn) => btn !== choiceButtons(c.d)[correctIndex(c.app)]);
  shownChoices(c.d)[wrongShown].click();
  assert.match(c.d.getElementById("explanation").textContent, /획득 점수: 0점/);
  assert.equal(c.app.run("app.state.score"), 0);
});

test("힌트: 다음 문항에서는 모든 보기가 보이고 [힌트]를 다시 쓸 수 있다", () => {
  const { app, d } = hintApp();
  d.getElementById("btn-hint").click();
  choiceButtons(d)[correctIndex(app)].click();
  clickNext(app);
  assert.equal(shownChoices(d).length, 4);
  assert.equal(d.getElementById("btn-hint").disabled, false);
});

test("힌트: 힌트 후 3문제, 힌트 없이 2문제를 맞히고 나머지를 틀리면 3.5 / 10이다", () => {
  const { app, d } = hintApp();
  for (let i = 0; i < 10; i++) {
    const right = correctIndex(app);
    if (i < 3) {
      d.getElementById("btn-hint").click();
      choiceButtons(d)[right].click();
    } else if (i < 5) {
      choiceButtons(d)[right].click();
    } else {
      choiceButtons(d)[(right + 1) % 4].click();
    }
    clickNext(app);
  }
  assert.equal(d.getElementById("score").textContent, "3.5 / 10");
  assert.equal(d.getElementById("result-notice").textContent, "");
});

/* ===== Task 15: 틀린 문제 다시 풀기 화면 ===== */

// pattern[i]가 true면 i번째 문제를 맞히고 false면 틀린다. 연습 모드로 한 판을 끝낸다.
function practiceRound(category, pattern) {
  const app = loadApp();
  startWithMode(app, category, "연습");
  const d = app.document;
  for (let i = 0; i < 10; i++) {
    const right = correctIndex(app);
    choiceButtons(d)[pattern[i] ? right : (right + 1) % 4].click();
    clickNext(app);
  }
  return { app, d };
}
const wrongThree = [true, false, true, false, true, true, false, true, true, true];
const retryIds = (app) => app.run("app.retry.pass.map((it) => it.id)").sort();
const wrongIds = (app) => app.run("app.state.wrong.map((it) => it.id)").sort();

function answerRetry(app, correct) {
  const d = app.document;
  const item = app.run("retryCurrent(app.retry)");
  const idx = correct ? item.answerIndex : (item.answerIndex + 1) % 4;
  choiceButtons(d)[idx].click();
  clickNext(app);
}

test("다시 풀기: 연습 결과에 틀린 문제가 있으면 버튼이 활성화되어 있다", () => {
  const { d } = practiceRound("과학", wrongThree);
  const btn = d.getElementById("btn-retry");
  assert.equal(btn.hidden, false);
  assert.equal(btn.disabled, false);
  assert.match(btn.textContent, /틀린 문제 다시 풀기/);
  assert.equal(d.getElementById("retry-note").textContent, "");
});

test("다시 풀기: 전부 맞힌 판에서도 버튼이 보이지만 비활성이고 안내가 붙는다", () => {
  const { d } = practiceRound("과학", Array(10).fill(true));
  const btn = d.getElementById("btn-retry");
  assert.equal(btn.hidden, false);
  assert.equal(btn.disabled, true);
  assert.equal(d.getElementById("retry-note").textContent, "틀린 문제가 없어요");
});

test("다시 풀기: 스피드·힌트 결과에는 버튼이 없다", () => {
  const app = loadApp();
  startWithMode(app, "과학", "힌트");
  for (let i = 0; i < 10; i++) {
    choiceButtons(app.document)[correctIndex(app)].click();
    clickNext(app);
  }
  assert.equal(app.document.getElementById("btn-retry").hidden, true);
  assert.equal(app.document.getElementById("retry-note").textContent, "");
});

test("다시 풀기: 누르면 틀렸던 문제만 나오고 안내 문구가 보이며 점수·타이머·힌트는 없다", () => {
  const { app, d } = practiceRound("한국사", wrongThree);
  d.getElementById("btn-retry").click();
  assert.deepEqual(visibleScreens(d), ["screen-quiz"]);
  assert.deepEqual(retryIds(app), wrongIds(app));
  assert.equal(retryIds(app).length, 3);
  assert.match(d.getElementById("progress").textContent, /다시 풀기 1 \/ 3/);
  assert.equal(d.getElementById("quiz-notice").hidden, false);
  assert.equal(d.getElementById("quiz-notice").textContent, "순위표에 기록되지 않음");
  assert.equal(d.getElementById("timer").hidden, true);
  assert.equal(d.getElementById("btn-hint").hidden, true);
});

test("다시 풀기: 정오·해설·출처는 보이고 획득 점수는 표시하지 않는다", () => {
  const { app, d } = practiceRound("한국사", wrongThree);
  d.getElementById("btn-retry").click();
  const item = app.run("retryCurrent(app.retry)");
  choiceButtons(d)[(item.answerIndex + 1) % 4].click();
  const exp = d.getElementById("explanation");
  assert.match(exp.textContent, /오답/);
  assert.match(exp.textContent, /출처: /);
  assert.doesNotMatch(exp.textContent, /획득 점수/);
  assert.match(choiceButtons(d)[item.answerIndex].textContent, /✓/);
});

test("다시 풀기: 맞히면 빠지고 틀리면 다음 바퀴에 다시 나오며, 모두 맞히면 복습 완료다", () => {
  const { app, d } = practiceRound("세계지리", wrongThree);
  d.getElementById("btn-retry").click();
  answerRetry(app, true);
  answerRetry(app, false);
  answerRetry(app, false);
  assert.equal(retryIds(app).length, 2, "맞힌 1개가 빠지고 2개가 남는다");
  assert.match(d.getElementById("progress").textContent, /다시 풀기 1 \/ 2/);
  answerRetry(app, true);
  answerRetry(app, true);
  assert.deepEqual(visibleScreens(d), ["screen-retry-done"]);
  assert.equal(d.getElementById("retry-done-title").textContent, "복습 완료");
});

test("다시 풀기: 처음 점수는 바뀌지 않는다", () => {
  const { app, d } = practiceRound("과학", wrongThree);
  const before = d.getElementById("score").textContent;
  assert.equal(before, "7 / 10");
  d.getElementById("btn-retry").click();
  for (let i = 0; i < 3; i++) answerRetry(app, true);
  assert.equal(app.run("app.state.score"), 7);
  assert.equal(d.getElementById("score").textContent, before);
});

test("다시 풀기: [다음] 연타로 문제를 건너뛰지 않는다", () => {
  const { app, d } = practiceRound("과학", wrongThree);
  d.getElementById("btn-retry").click();
  const item = app.run("retryCurrent(app.retry)");
  choiceButtons(d)[item.answerIndex].click();
  clickNext(app);
  app.run("onNext(); onNext();");
  assert.match(d.getElementById("progress").textContent, /다시 풀기 2 \/ 3/);
});

test("다시 풀기: 끝난 뒤 [처음으로]로 돌아가 새 판을 정상으로 시작한다", () => {
  const { app, d } = practiceRound("과학", wrongThree);
  d.getElementById("btn-retry").click();
  for (let i = 0; i < 3; i++) answerRetry(app, true);
  d.getElementById("btn-retry-home").click();
  assert.deepEqual(visibleScreens(d), ["screen-categories"]);
  startWithMode(app, "예술과 문화", "연습");
  assert.equal(d.getElementById("progress").textContent, "1 / 10");
  assert.equal(d.getElementById("quiz-notice").hidden, true);
  assert.equal(app.run("app.retry"), null);
});

test("다시 풀기: 중간에 [그만두기]를 누르면 카테고리 선택으로 돌아간다", () => {
  const { app, d } = practiceRound("과학", wrongThree);
  d.getElementById("btn-retry").click();
  d.getElementById("btn-quit").click();
  assert.deepEqual(visibleScreens(d), ["screen-categories"]);
  assert.equal(app.run("app.retry"), null);
});

test("연습 결과 화면에는 '순위표에 기록되지 않음'이 남아 있다", () => {
  const { d } = practiceRound("과학", wrongThree);
  assert.equal(d.getElementById("result-notice").textContent, "순위표에 기록되지 않음");
});


/* ===== Task 18: 결과 화면에서 닉네임 입력과 순위표 기록 ===== */

const boardOf = (storage, mode, category) => JSON.parse(storage.getItem(`quiz:v1:board:${mode}:${category}`) || "[]");
const boardKeys = (storage) => [...storage.map.keys()].filter((k) => k.includes(":board:"));

// 힌트 모드 한 판을 끝낸다. 앞의 nCorrect개는 맞히고 나머지는 틀린다.
function finishHintRound(app, nCorrect) {
  const d = app.document;
  for (let i = 0; i < 10; i++) {
    const right = correctIndex(app);
    choiceButtons(d)[i < nCorrect ? right : (right + 1) % 4].click();
    clickNext(app);
  }
}
const typeNickname = (app, text) => { app.document.getElementById("nickname-input").value = text; };
const saveNicknameClick = (app) => app.document.getElementById("btn-nickname-save").click();

test("기록: 스피드·힌트 판은 닉네임을 묻지 않고 곧바로 시작한다", () => {
  const app = loadApp({ clock: makeClock(), storage: new FakeStorage() });
  startWithMode(app, "과학", "스피드");
  assert.deepEqual(visibleScreens(app.document), ["screen-quiz"]);
  assert.equal(app.document.getElementById("timer").textContent, "남은 시간 15초");
  const hint = loadApp({ storage: new FakeStorage() });
  startWithMode(hint, "과학", "힌트");
  assert.deepEqual(visibleScreens(hint.document), ["screen-quiz"]);
});

test("기록: 닉네임이 없는 첫 판은 결과 화면에 입력 칸이 나오고 아직 저장되지 않는다", () => {
  const st = new FakeStorage();
  const app = loadApp({ storage: st });
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 6);
  const d = app.document;
  assert.deepEqual(visibleScreens(d), ["screen-result"]);
  assert.equal(d.getElementById("nickname-form").hidden, false);
  assert.match(d.getElementById("record-status").textContent, /닉네임/);
  assert.deepEqual(boardKeys(st), []);
});

test("기록: 빈 값·공백·13자 닉네임은 안내만 보이고 저장되지 않는다", () => {
  for (const bad of ["", "   ", "가".repeat(13)]) {
    const st = new FakeStorage();
    const app = loadApp({ storage: st });
    startWithMode(app, "과학", "힌트");
    finishHintRound(app, 6);
    typeNickname(app, bad);
    saveNicknameClick(app);
    assert.equal(app.document.getElementById("nickname-error").hidden, false);
    assert.match(app.document.getElementById("nickname-error").textContent, /1~12자/);
    assert.deepEqual(boardKeys(st), []);
    assert.equal(st.getItem("quiz:v1:nickname"), null);
  }
});

test("기록: 올바른 닉네임을 저장하면 순위가 나오고 표와 닉네임이 저장된다", () => {
  const st = new FakeStorage();
  const app = loadApp({ storage: st });
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 6);
  typeNickname(app, "  민수 ");
  saveNicknameClick(app);
  const d = app.document;
  assert.match(d.getElementById("record-status").textContent, /1위에 올랐어요/);
  assert.equal(d.getElementById("nickname-form").hidden, true);
  const board = boardOf(st, "hint", "과학");
  assert.equal(board.length, 1);
  assert.equal(board[0].nickname, "민수");
  assert.equal(board[0].score, 6);
  assert.match(board[0].date, /^\d{4}-\d{2}-\d{2}$/);
  assert.equal(st.getItem("quiz:v1:nickname"), "민수");
});

test("기록: 닉네임이 이미 저장되어 있으면 폼 없이 곧바로 기록된다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:nickname", "영희");
  const app = loadApp({ storage: st });
  startWithMode(app, "한국사", "힌트");
  finishHintRound(app, 4);
  assert.equal(app.document.getElementById("nickname-form").hidden, true);
  assert.match(app.document.getElementById("record-status").textContent, /1위에 올랐어요/);
  assert.equal(boardOf(st, "hint", "한국사")[0].nickname, "영희");
});

test("기록: 같은 판은 한 번만 기록된다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:nickname", "영희");
  const app = loadApp({ storage: st });
  startWithMode(app, "한국사", "힌트");
  finishHintRound(app, 4);
  app.run("saveRecord(); saveRecord();");
  assert.equal(boardOf(st, "hint", "한국사").length, 1);
});

test("기록: 두 번째 판부터는 닉네임을 묻지 않고, 표는 모드·카테고리별로 따로다", () => {
  const st = new FakeStorage();
  const app = loadApp({ storage: st });
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 6);
  typeNickname(app, "민수");
  saveNicknameClick(app);
  app.document.getElementById("btn-home").click();
  startWithMode(app, "한국사", "힌트");
  finishHintRound(app, 5);
  assert.equal(app.document.getElementById("nickname-form").hidden, true);
  assert.equal(boardOf(st, "hint", "과학").length, 1);
  assert.equal(boardOf(st, "hint", "한국사").length, 1);
  assert.equal(boardOf(st, "speed", "과학").length, 0);
});

test("기록: 연습 모드는 입력 칸도 기록도 없다", () => {
  const st = new FakeStorage();
  const app = loadApp({ storage: st });
  startWithMode(app, "과학", "연습");
  const d = app.document;
  for (let i = 0; i < 10; i++) {
    choiceButtons(d)[correctIndex(app)].click();
    clickNext(app);
  }
  assert.equal(d.getElementById("nickname-form").hidden, true);
  assert.equal(d.getElementById("record-status").textContent, "");
  assert.equal(d.getElementById("result-notice").textContent, "순위표에 기록되지 않음");
  assert.deepEqual(boardKeys(st), []);
});

test("기록: 저장소를 쓸 수 없으면 안내만 보이고 퀴즈는 계속된다", () => {
  const app = loadApp(); // window.localStorage 없음
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 6);
  typeNickname(app, "민수");
  saveNicknameClick(app);
  assert.match(app.document.getElementById("record-status").textContent, /기록을 저장할 수 없어요/);
  app.document.getElementById("btn-home").click();
  startWithMode(app, "과학", "힌트");
  assert.deepEqual(visibleScreens(app.document), ["screen-quiz"]);
});

test("기록: 10건이 찬 표에 낮은 점수면 순위권 밖이다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:nickname", "영희");
  const full = Array.from({ length: 10 }, (_, i) => ({ nickname: `n${i}`, score: 10, date: "2026-10-01" }));
  st.setItem("quiz:v1:board:hint:과학", JSON.stringify(full));
  const app = loadApp({ storage: st });
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 0);
  assert.match(app.document.getElementById("record-status").textContent, /순위권 밖/);
  assert.equal(boardOf(st, "hint", "과학").length, 10);
});

test("기록: 닉네임에 HTML이 들어 있어도 글자 그대로 보인다", () => {
  const st = new FakeStorage();
  const app = loadApp({ storage: st });
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 6);
  typeNickname(app, "<b>x</b>");
  saveNicknameClick(app);
  assert.match(app.document.getElementById("record-status").textContent, /<b>x<\/b>/);
  assert.equal(app.document.getElementById("record-status").kids.length, 0, "자식 요소를 만들지 않는다");
});

test("기록: 스피드 모드도 판이 끝나면 기록 흐름을 탄다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:nickname", "영희");
  const clock = makeClock();
  const app = loadApp({ clock, storage: st });
  startWithMode(app, "세계지리", "스피드");
  for (let i = 0; i < 10; i++) {
    choiceButtons(app.document)[correctIndex(app)].click();
    clickNext(app);
  }
  assert.equal(boardOf(st, "speed", "세계지리")[0].score, 10);
  assert.match(app.document.getElementById("record-status").textContent, /1위에 올랐어요/);
});

/* ===== Task 19: 순위표 화면 ===== */

const tab = (d, containerId, label) => d.getElementById(containerId).kids.find((b) => b.textContent === label);
const rows = (d) => d.getElementById("board-body").kids.map((tr) => tr.kids.map((td) => td.textContent));
const openBoardFromHome = (app) => app.document.getElementById("btn-board").click();
const putBoard = (st, mode, category, list) => st.setItem(`quiz:v1:board:${mode}:${category}`, JSON.stringify(list));

test("순위표: 카테고리 화면의 [순위표 보기]로 열고 모드 탭 2개·카테고리 탭 4개가 있다", () => {
  const app = loadApp({ storage: new FakeStorage() });
  const d = app.document;
  openBoardFromHome(app);
  assert.deepEqual(visibleScreens(d), ["screen-board"]);
  assert.deepEqual(d.getElementById("board-mode-tabs").kids.map((b) => b.textContent), ["스피드", "힌트"]);
  assert.deepEqual(d.getElementById("board-category-tabs").kids.map((b) => b.textContent), CATEGORIES);
});

test("순위표: 기록이 없으면 안내가 보이고 표는 비어 있다", () => {
  const app = loadApp({ storage: new FakeStorage() });
  openBoardFromHome(app);
  const d = app.document;
  assert.equal(d.getElementById("board-empty").hidden, false);
  assert.deepEqual(rows(d), []);
  assert.equal(d.getElementById("board-error").hidden, true);
});

test("순위표: 저장된 순서대로 순위·닉네임·점수·날짜가 보인다", () => {
  const st = new FakeStorage();
  putBoard(st, "speed", "한국사", [
    { nickname: "민수", score: 9, date: "2026-10-03" },
    { nickname: "영희", score: 7.5, date: "2026-10-02" },
  ]);
  const app = loadApp({ storage: st });
  openBoardFromHome(app);
  assert.deepEqual(rows(app.document), [["1", "민수", "9", "2026-10-03"], ["2", "영희", "7.5", "2026-10-02"]]);
  assert.equal(app.document.getElementById("board-empty").hidden, true);
});

test("순위표: 8개 표가 서로 섞이지 않는다", () => {
  const st = new FakeStorage();
  const modes = [["speed", "스피드"], ["hint", "힌트"]];
  modes.forEach(([mode], mi) => CATEGORIES.forEach((cat, ci) => {
    putBoard(st, mode, cat, [{ nickname: `${mode}-${cat}`, score: 5 + ci, date: "2026-10-01" }]);
  }));
  const app = loadApp({ storage: st });
  const d = app.document;
  openBoardFromHome(app);
  for (const [mode, label] of modes) {
    tab(d, "board-mode-tabs", label).click();
    for (const cat of CATEGORIES) {
      tab(d, "board-category-tabs", cat).click();
      assert.deepEqual(rows(d).map((r) => r[1]), [`${mode}-${cat}`]);
      assert.match(d.getElementById("board-title").textContent, new RegExp(`${label}.*${cat}`));
    }
  }
});

test("순위표: 저장소를 쓸 수 없으면 안내가 보이고 앱은 멈추지 않는다", () => {
  const app = loadApp();
  openBoardFromHome(app);
  assert.equal(app.document.getElementById("board-error").hidden, false);
  assert.deepEqual(visibleScreens(app.document), ["screen-board"]);
});

test("순위표: 저장된 값이 깨져 있어도 빈 표로 열린다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:board:speed:한국사", "{{{");
  const app = loadApp({ storage: st });
  openBoardFromHome(app);
  assert.deepEqual(rows(app.document), []);
  assert.equal(app.document.getElementById("board-empty").hidden, false);
});

test("순위표: 닉네임의 HTML은 글자 그대로 보인다", () => {
  const st = new FakeStorage();
  putBoard(st, "speed", "한국사", [{ nickname: "<b>x</b>", score: 5, date: "2026-10-01" }]);
  const app = loadApp({ storage: st });
  openBoardFromHome(app);
  const cell = app.document.getElementById("board-body").kids[0].kids[1];
  assert.equal(cell.textContent, "<b>x</b>");
  assert.equal(cell.kids.length, 0);
});

test("순위표: 닉네임을 바꾸면 이후 기록부터 새 닉네임이 쓰이고 옛 기록은 그대로다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:nickname", "민수");
  putBoard(st, "hint", "과학", [{ nickname: "민수", score: 5, date: "2026-10-01" }]);
  const app = loadApp({ storage: st });
  const d = app.document;
  openBoardFromHome(app);
  assert.equal(d.getElementById("board-nickname").textContent, "민수");
  d.getElementById("board-nickname-input").value = "영희";
  d.getElementById("btn-board-nickname").click();
  assert.equal(st.getItem("quiz:v1:nickname"), "영희");
  assert.equal(d.getElementById("board-nickname").textContent, "영희");
  tab(d, "board-mode-tabs", "힌트").click();
  tab(d, "board-category-tabs", "과학").click();
  assert.equal(rows(d)[0][1], "민수", "옛 기록은 바뀌지 않는다");
  d.getElementById("btn-board-back").click();
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 9);
  assert.equal(boardOf(st, "hint", "과학")[0].nickname, "영희");
});

test("순위표: 규칙에 맞지 않는 닉네임은 바뀌지 않고 안내가 보인다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:nickname", "민수");
  const app = loadApp({ storage: st });
  const d = app.document;
  openBoardFromHome(app);
  for (const bad of ["", "   ", "가".repeat(13)]) {
    d.getElementById("board-nickname-input").value = bad;
    d.getElementById("btn-board-nickname").click();
    assert.equal(d.getElementById("board-nickname-error").hidden, false);
    assert.equal(st.getItem("quiz:v1:nickname"), "민수");
  }
});

test("순위표: 스피드·힌트 결과 화면의 [순위표 보기]는 그 판의 표로 간다", () => {
  const st = new FakeStorage();
  st.setItem("quiz:v1:nickname", "영희");
  const app = loadApp({ storage: st });
  startWithMode(app, "과학", "힌트");
  finishHintRound(app, 8);
  const d = app.document;
  assert.equal(d.getElementById("btn-result-board").hidden, false);
  d.getElementById("btn-result-board").click();
  assert.deepEqual(visibleScreens(d), ["screen-board"]);
  assert.match(d.getElementById("board-title").textContent, /힌트.*과학/);
  assert.deepEqual(rows(d)[0].slice(0, 3), ["1", "영희", "8"]);
});

test("순위표: 연습 결과 화면에는 [순위표 보기]가 없다", () => {
  const app = loadApp({ storage: new FakeStorage() });
  startWithMode(app, "과학", "연습");
  for (let i = 0; i < 10; i++) {
    choiceButtons(app.document)[correctIndex(app)].click();
    clickNext(app);
  }
  assert.equal(app.document.getElementById("btn-result-board").hidden, true);
});

test("순위표: [뒤로]는 카테고리 선택으로 돌아간다", () => {
  const app = loadApp({ storage: new FakeStorage() });
  openBoardFromHome(app);
  app.document.getElementById("btn-board-back").click();
  assert.deepEqual(visibleScreens(app.document), ["screen-categories"]);
});

/* ===== 문제 화면 위쪽의 누적 점수 ===== */

test("누적 점수: 힌트를 쓰고 맞히면 점수 표시가 0.5로, 이어서 힌트 없이 맞히면 1.5로 오른다", () => {
  const app = loadApp();
  startWithMode(app, "과학", "힌트");
  const d = app.document;
  const live = () => d.getElementById("live-score").textContent;
  assert.equal(live(), "점수 0");
  d.getElementById("btn-hint").click();
  choiceButtons(d)[correctIndex(app)].click();
  assert.equal(live(), "점수 0.5");
  clickNext(app);
  assert.equal(live(), "점수 0.5", "다음 문제로 넘어가도 유지된다");
  choiceButtons(d)[correctIndex(app)].click();
  assert.equal(live(), "점수 1.5");
});

test("누적 점수: 틀리면 오르지 않고, 연습·스피드 모드에도 보인다", () => {
  for (const mode of ["연습", "스피드"]) {
    const app = loadApp({ clock: makeClock() });
    startWithMode(app, "한국사", mode);
    const d = app.document;
    assert.equal(d.getElementById("live-score").hidden, false);
    choiceButtons(d)[wrongIndexNow(app)].click();
    assert.equal(d.getElementById("live-score").textContent, "점수 0");
    clickNext(app);
    choiceButtons(d)[correctIndex(app)].click();
    assert.equal(d.getElementById("live-score").textContent, "점수 1");
  }
});

test("누적 점수: 다시 풀기에서는 점수를 보여 주지 않는다", () => {
  const { app, d } = practiceRound("과학", wrongThree);
  d.getElementById("btn-retry").click();
  assert.equal(d.getElementById("live-score").hidden, true);
});
