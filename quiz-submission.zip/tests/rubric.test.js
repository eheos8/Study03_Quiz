// 과제 채점 기준(페이지 항목)을 항목별로 한 번에 확인하는 회귀 테스트.
// 3단계(저장소·순위표)가 켜진 상태에서도 채점 항목이 그대로 동작하는지 본다.
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadApp, makeClock } = require("./fake-dom.js");
const { FakeStorage } = require("./helpers.js");

const screens = (d) => d.querySelectorAll(".screen").filter((s) => !s.hidden).map((s) => s.id);
const click = (d, id) => d.getElementById(id).click();
const categoryButton = (d, name) => d.getElementById("category-list").kids.find((b) => b.textContent === name);
const modeButton = (d, label) => d.getElementById("mode-list").kids.find((b) => b.kids[0].textContent === label);
const choices = (d) => d.getElementById("choices").kids;
const rightIndex = (app) => app.run("app.state.items[app.state.index].answerIndex");
const start = (app, category, mode) => {
  categoryButton(app.document, category).click();
  modeButton(app.document, mode).click();
};
const fresh = () => {
  const clock = makeClock();
  return { clock, app: loadApp({ clock, storage: new FakeStorage() }) };
};

test("[채점] 페이지가 열린다: 오류 없이 카테고리 선택 화면이 보인다", () => {
  const { app } = fresh();
  assert.deepEqual(screens(app.document), ["screen-categories"]);
  assert.equal(app.document.getElementById("error-banner").hidden, true);
});

test("[채점] 카테고리를 고른 뒤 모드 선택 화면에 연습, 스피드, 힌트 3개가 나온다", () => {
  const { app } = fresh();
  categoryButton(app.document, "한국사").click();
  assert.deepEqual(screens(app.document), ["screen-mode"]);
  assert.deepEqual(app.document.getElementById("mode-list").kids.map((b) => b.kids[0].textContent), ["연습", "스피드", "힌트"]);
});

test("[채점] 스피드: 남은 시간이 15초부터 줄고 0초에 시간 초과로 처리된다", () => {
  const { app, clock } = fresh();
  start(app, "과학", "스피드");
  const d = app.document;
  assert.deepEqual(screens(d), ["screen-quiz"], "닉네임 입력 없이 곧바로 문제가 나온다");
  assert.equal(d.getElementById("timer").textContent, "남은 시간 15초");
  clock.advance(5000);
  assert.equal(d.getElementById("timer").textContent, "남은 시간 10초");
  clock.advance(10000);
  assert.equal(d.getElementById("timer").textContent, "남은 시간 0초");
  assert.match(d.getElementById("explanation").textContent, /시간 초과/);
  assert.equal(app.run("app.state.score"), 0);
});

test("[채점] 힌트: 누르면 오답 2개가 지워지고, 힌트를 쓰고 맞힌 문항은 0.5점이다", () => {
  const { app } = fresh();
  start(app, "과학", "힌트");
  const d = app.document;
  const right = rightIndex(app);
  click(d, "btn-hint");
  assert.equal(choices(d).filter((b) => b.hidden).length, 2);
  assert.equal(choices(d)[right].hidden, false);
  choices(d)[right].click();
  assert.equal(app.run("app.state.score"), 0.5);
  assert.match(d.getElementById("explanation").textContent, /획득 점수: 0\.5점/);
});

test("[채점] 연습 결과 화면에 [틀린 문제 다시 풀기]가 있다(틀린 문제가 있을 때도 없을 때도)", () => {
  for (const allCorrect of [false, true]) {
    const { app } = fresh();
    start(app, "세계지리", "연습");
    const d = app.document;
    for (let i = 0; i < 10; i++) {
      const right = rightIndex(app);
      choices(d)[allCorrect ? right : (right + 1) % 4].click();
      click(d, "btn-next");
    }
    const button = d.getElementById("btn-retry");
    assert.equal(button.hidden, false, "버튼이 보인다");
    assert.match(button.textContent, /틀린 문제 다시 풀기/);
    assert.equal(button.disabled, allCorrect);
  }
});

test("[채점] 페이지 화면에 학번과 이름이 보인다", () => {
  const { app } = fresh();
  const text = app.document.getElementById("student-info").textContent;
  assert.match(text, /2601946/);
  assert.match(text, /설소희/);
});
