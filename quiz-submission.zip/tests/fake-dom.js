// 브라우저가 없는 환경에서 script.js의 화면 코드를 돌려 보기 위한 최소 가짜 DOM (개발용)
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

class FakeElement {
  constructor(tag, id = "", className = "", hidden = false) {
    this.tagName = tag.toUpperCase();
    this.id = id;
    this.className = className;
    this.hidden = hidden;
    this.disabled = false;
    this.value = "";
    this._kids = [];
    this.dataset = {};
    this.attrs = {};
    this.listeners = {};
    this._text = "";
  }
  get classList() {
    const el = this;
    const list = () => el.className.split(/\s+/).filter(Boolean);
    return {
      add: (c) => { if (!list().includes(c)) el.className = [...list(), c].join(" "); },
      remove: (c) => { el.className = list().filter((x) => x !== c).join(" "); },
      contains: (c) => list().includes(c),
      toggle: (c, on) => {
        const has = list().includes(c);
        const want = on === undefined ? !has : on;
        if (want && !has) el.className = [...list(), c].join(" ");
        if (!want && has) el.className = list().filter((x) => x !== c).join(" ");
      },
    };
  }
  // 실제 DOM의 children은 HTMLCollection이라 forEach/map 등 배열 메서드가 없다. 같은 제약을 흉내 낸다.
  get children() {
    const kids = this._kids;
    const collection = { length: kids.length, item: (i) => kids[i] || null, [Symbol.iterator]: () => kids[Symbol.iterator]() };
    kids.forEach((k, i) => { collection[i] = k; });
    return collection;
  }
  // 테스트 코드에서 편하게 쓰는 진짜 배열
  get kids() { return this._kids; }
  set textContent(value) { this._text = String(value); this._kids = []; }
  get textContent() { return this._text + this._kids.map((c) => c.textContent).join(""); }
  appendChild(child) { this._kids.push(child); return child; }
  append(...nodes) {
    for (const n of nodes) this.appendChild(typeof n === "string" ? Object.assign(new FakeElement("#text"), { _text: n }) : n);
  }
  replaceChildren(...nodes) { this._kids = []; this._text = ""; this.append(...nodes); }
  setAttribute(name, value) { this.attrs[name] = String(value); }
  addEventListener(type, fn) { (this.listeners[type] = this.listeners[type] || []).push(fn); }
  click() {
    if (this.disabled) return;
    for (const fn of this.listeners.click || []) fn({ target: this });
  }
  focus() {}
  key(key) { for (const fn of this.listeners.keydown || []) fn({ key }); }
  descendants() { return this._kids.flatMap((c) => [c, ...c.descendants()]); }
  querySelectorAll(sel) {
    const cls = sel.startsWith(".") ? sel.slice(1) : null;
    return this.descendants().filter((e) => (cls ? e.classList.contains(cls) : e.tagName === sel.toUpperCase()));
  }
}

class FakeDocument {
  constructor(html) {
    this.byId = {};
    this.statics = [];
    this.listeners = {};
    const tagRe = /<(section|footer|div|p|h1|h2|h3|button|ul|ol|li|main|span|a|label|input|table|tbody|thead|tr|th|td)\b([^>]*)>/g;
    let m;
    while ((m = tagRe.exec(html))) {
      const attrs = m[2];
      const id = (/\bid="([^"]*)"/.exec(attrs) || [])[1];
      if (!id) continue;
      const cls = (/\bclass="([^"]*)"/.exec(attrs) || [])[1] || "";
      const el = new FakeElement(m[1], id, cls, /(^|\s)hidden(\s|=|$)/.test(attrs));
      // <button id="x">글자</button>처럼 안에 태그 없이 글자만 있으면 그 글자를 읽어 둔다.
      const inner = /^([^<]*)</.exec(html.slice(tagRe.lastIndex));
      if (inner && inner[1].trim()) el._text = inner[1].trim();
      this.byId[id] = el;
      this.statics.push(el);
    }
  }
  getElementById(id) { return this.byId[id] || null; }
  createElement(tag) { return new FakeElement(tag); }
  querySelectorAll(sel) {
    const cls = sel.startsWith(".") ? sel.slice(1) : null;
    return this.statics.filter((e) => (cls ? e.classList.contains(cls) : e.tagName === sel.toUpperCase()));
  }
  addEventListener(type, fn) { (this.listeners[type] = this.listeners[type] || []).push(fn); }
  dispatch(type) { for (const fn of this.listeners[type] || []) fn({}); }
}

// index.html + questions.js + script.js를 한 컨텍스트에 올리고 DOMContentLoaded를 보낸다.
// 시간을 직접 움직이는 가짜 시계(setInterval/clearInterval/Date.now를 대신한다)
function makeClock() {
  const c = { now: 1000000, timers: [], nextId: 1 };
  c.setInterval = (fn, ms) => { const id = c.nextId++; c.timers.push({ id, fn, ms, next: c.now + ms }); return id; };
  c.clearInterval = (id) => { c.timers = c.timers.filter((t) => t.id !== id); };
  c.advance = (ms) => {
    const end = c.now + ms;
    for (;;) {
      const due = c.timers.filter((t) => t.next <= end).sort((a, b) => a.next - b.next)[0];
      if (!due) break;
      c.now = Math.max(c.now, due.next);
      due.next += due.ms;
      due.fn();
    }
    c.now = Math.max(c.now, end);
  };
  // new Date()도 가짜 시각을 쓰도록 생성자로 동작하게 한다(인자가 있으면 진짜 Date처럼 동작).
  const RealDate = Date;
  c.Date = function FakeDate(...args) {
    return args.length ? new RealDate(...args) : new RealDate(c.now);
  };
  c.Date.now = () => c.now;
  return c;
}

function loadApp({ mutateQuestions, skipQuestions, clock, storage } = {}) {
  const root = path.join(__dirname, "..");
  const document = new FakeDocument(fs.readFileSync(path.join(root, "index.html"), "utf8"));
  const timing = clock
    ? { Date: clock.Date, setInterval: clock.setInterval, clearInterval: clock.clearInterval }
    : { Date, setInterval, clearInterval };
  const extra = storage ? { window: { localStorage: storage } } : {};
  const ctx = vm.createContext({ document, console, Math, setTimeout, clearTimeout, ...timing, ...extra });
  if (!skipQuestions) vm.runInContext(fs.readFileSync(path.join(root, "questions.js"), "utf8"), ctx, { filename: "questions.js" });
  if (mutateQuestions) vm.runInContext(`(${mutateQuestions.toString()})(QUESTIONS)`, ctx);
  vm.runInContext(fs.readFileSync(path.join(root, "script.js"), "utf8"), ctx, { filename: "script.js" });
  document.dispatch("DOMContentLoaded");
  return { document, run: (code) => vm.runInContext(code, ctx) };
}

module.exports = { FakeElement, FakeDocument, loadApp, makeClock };
