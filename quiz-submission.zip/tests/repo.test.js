const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");

// 과제 채점 기준: 저장소에 이 세 파일이 대소문자까지 정확히 있어야 한다.
for (const name of ["PRD.md", "IMPL-PLAN.md", "CLAUDE.md"]) {
  test(`저장소 루트에 ${name}가 정확한 이름으로 있다`, () => {
    assert.ok(fs.readdirSync(root).includes(name), `${name} 없음`);
  });
}

test("CLAUDE.md에 문항 작성 규칙(5.4.2)이 있다", () => {
  const text = fs.readFileSync(path.join(root, "CLAUDE.md"), "utf8");
  assert.match(text, /문항 작성 규칙/);
  assert.match(text, /5\.4\.2/);
  assert.match(text, /정답은 하나/);
  assert.match(text, /출처/);
  assert.match(text, /최상급/);
  assert.match(text, /기준/);
  assert.match(text, /시점/);
});

test("배포 파일 4개가 모두 있다", () => {
  for (const name of ["index.html", "style.css", "script.js", "questions.js"]) {
    assert.ok(fs.existsSync(path.join(root, name)), `${name} 없음`);
  }
});

test("앱 파일에는 외부 주소 요청(CDN·외부 폰트·@import)이 없다", () => {
  for (const name of ["index.html", "style.css", "script.js"]) {
    const text = fs.readFileSync(path.join(root, name), "utf8");
    assert.doesNotMatch(text, /https?:\/\//, `${name}에 외부 주소가 있다`);
    assert.doesNotMatch(text, /@import/, `${name}에 @import가 있다`);
  }
});

test("script.js가 getElementById로 찾는 id가 모두 index.html에 있고, id는 중복되지 않는다", () => {
  const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
  const script = fs.readFileSync(path.join(root, "script.js"), "utf8");
  const declared = [...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
  assert.equal(new Set(declared).size, declared.length, "중복된 id가 있다");
  const used = new Set([...script.matchAll(/getElementById\("([^"]+)"\)/g)].map((m) => m[1]));
  for (const id of used) assert.ok(declared.includes(id), `index.html에 id="${id}"가 없다`);
  for (const screen of ["categories", "mode", "quiz", "result", "retry-done"]) {
    assert.ok(declared.includes(`screen-${screen}`), `screen-${screen} 없음`);
  }
});

/* ===== quiz-validate 명령(프로젝트 전용, 읽기 전용) ===== */

const commandFile = path.join(root, ".claude", "commands", "quiz-validate.md");

test("quiz-validate: 프로젝트 안(.claude/commands)에 있고 개인 폴더에 두지 않는다", () => {
  assert.ok(fs.existsSync(commandFile), ".claude/commands/quiz-validate.md 없음");
});

test("quiz-validate: 머리말에 description이 있고 allowed-tools는 읽기 도구만 허용한다", () => {
  const text = fs.readFileSync(commandFile, "utf8");
  const frontmatter = /^---\r?\n([\s\S]*?)\r?\n---/.exec(text);
  assert.ok(frontmatter, "머리말(---) 필요");
  assert.match(frontmatter[1], /^description:\s*\S+/m);
  const tools = (/^allowed-tools:\s*(.+)$/m.exec(frontmatter[1]) || [])[1] || "";
  assert.ok(tools.length > 0, "allowed-tools가 있어야 한다");
  for (const tool of ["Read", "Grep", "Glob"]) assert.ok(tools.includes(tool), `${tool} 허용`);
  for (const bad of ["Edit", "Write", "Bash", "MultiEdit", "NotebookEdit"]) {
    assert.ok(!tools.includes(bad), `${bad}는 허용하면 안 된다`);
  }
});

test("quiz-validate: CLAUDE.md와 questions.js를 불러오고 점검만 하도록 지시한다", () => {
  const text = fs.readFileSync(commandFile, "utf8");
  assert.match(text, /@CLAUDE\.md/);
  assert.match(text, /@questions\.js/);
  assert.match(text, /고치지 않는다/);
  assert.match(text, /규칙 번호/);
  for (const n of ["1", "2", "3"]) assert.match(text, new RegExp(`규칙 ${n}`));
  assert.match(text, /\|\s*id\s*\|.*어긴 규칙/, "결과 표의 머리글이 있어야 한다");
});

test("quiz-validate: 규칙 1~3의 이름이 CLAUDE.md의 문항 작성 규칙과 같다", () => {
  const rules = fs.readFileSync(path.join(root, "CLAUDE.md"), "utf8");
  const command = fs.readFileSync(commandFile, "utf8");
  for (const phrase of ["정답은 하나", "출처", "최상급"]) {
    assert.match(rules, new RegExp(phrase), `CLAUDE.md에 ${phrase}`);
    assert.match(command, new RegExp(phrase), `명령에 ${phrase}`);
  }
});

/* ===== quiz-daily 명령: quiz-add 1 → (성공하면) quiz-validate ===== */

const dailyFile = path.join(root, ".claude", "commands", "quiz-daily.md");
const readDaily = () => fs.readFileSync(dailyFile, "utf8");

test("quiz-daily: 프로젝트 전용 위치에 있고 머리말에 description이 있다", () => {
  assert.ok(fs.existsSync(dailyFile), ".claude/commands/quiz-daily.md 없음");
  const fm = /^---\r?\n([\s\S]*?)\r?\n---/.exec(readDaily());
  assert.ok(fm, "머리말(---) 필요");
  assert.match(fm[1], /^description:\s*\S+/m);
});

test("quiz-daily: 명령을 부를 도구(SlashCommand)만 허용하고 쓰기·실행 도구는 허용하지 않는다", () => {
  const fm = /^---\r?\n([\s\S]*?)\r?\n---/.exec(readDaily());
  const tools = (/^allowed-tools:\s*(.+)$/m.exec(fm[1]) || [])[1] || "";
  assert.match(tools, /SlashCommand/);
  for (const bad of ["Edit", "Write", "Bash", "MultiEdit", "NotebookEdit"]) {
    assert.ok(!tools.includes(bad), `${bad}는 허용하면 안 된다`);
  }
});

test("quiz-daily: 두 명령 파일을 경로로 가리킨다", () => {
  const text = readDaily();
  assert.match(text, /\.claude\/commands\/quiz-add\.md/);
  assert.match(text, /\.claude\/commands\/quiz-validate\.md/);
});

test("quiz-daily: /quiz-add를 인수 1로 고정해 먼저, /quiz-validate를 인수 없이 나중에 실행한다", () => {
  const text = readDaily();
  assert.match(text, /\/quiz-add 1/);
  assert.match(text, /인수는? (항상 )?1로 고정/);
  assert.match(text, /\/quiz-validate[^\n]*인수 없이/);
  const addAt = text.indexOf("/quiz-add 1");
  const validateAt = text.indexOf("/quiz-validate");
  assert.ok(addAt >= 0 && validateAt > addAt, "quiz-add가 먼저 나와야 한다");
});

test("quiz-daily: quiz-add가 성공했을 때만 점검하고, 실패·중단·파일 없음이면 멈춘다", () => {
  const text = readDaily();
  assert.match(text, /성공/);
  assert.match(text, /실행하지 않고 멈춘다/);
  assert.match(text, /quiz-add\.md`?가 없으면/);
});

test("quiz-daily: 두 명령의 절차를 이 파일에 다시 적지 않는다(quiz-validate.md의 문장을 베끼지 않았다)", () => {
  const daily = readDaily();
  const validate = fs.readFileSync(commandFile, "utf8").replace(/^---[\s\S]*?\r?\n---\r?\n/, "");
  const copied = validate
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.length >= 20 && !/^\|?[-| ]+\|?$/.test(line))
    .filter((line) => daily.includes(line));
  assert.deepEqual(copied, [], `베낀 문장: ${copied.join(" / ")}`);
  assert.doesNotMatch(daily, /문항마다 확인할 것|점검의 한계|어긴 규칙/);
});

test("quiz-daily: 이 명령에 준 인자는 무시하고 모델이 임의로 부르지 않는다", () => {
  const text = readDaily();
  assert.match(text, /인자[^\n]*무시/);
  const fm = /^---\r?\n([\s\S]*?)\r?\n---/.exec(text);
  assert.match(fm[1], /^disable-model-invocation:\s*true/m);
});
