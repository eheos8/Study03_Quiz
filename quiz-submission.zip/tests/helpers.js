// 테스트용 공용 도구 (개발용, 배포 파일 아님)

// 주어진 값을 순환해서 돌려주는 결정적 rng
function seqRng(values) {
  let i = 0;
  return () => values[i++ % values.length];
}

// 형식에 맞는 문항 하나 (overrides로 필드를 덮어씀. undefined를 주면 그 필드가 없어짐)
function validQuestion(overrides = {}) {
  return {
    id: "t-01",
    category: "한국사",
    question: "문제",
    choices: ["a", "b", "c", "d"],
    answer: 0,
    explanation: "해설",
    source: "출처",
    ...overrides,
  };
}

// 카테고리의 가짜 문항 n개. id는 f-<카테고리>-<번호>, 정답 위치는 번호에 따라 0~3으로 돈다.
function fakeQuestions(category, n = 10) {
  return Array.from({ length: n }, (_, i) =>
    validQuestion({
      id: `f-${category}-${i + 1}`,
      category,
      question: `${category} 문제 ${i + 1}`,
      choices: [`${i}-a`, `${i}-b`, `${i}-c`, `${i}-d`],
      answer: i % 4,
    })
  );
}

// localStorage를 흉내 내는 Map 기반 저장소. 읽기·쓰기 실패도 흉내 낼 수 있다.
class FakeStorage {
  constructor({ throwOnGet = false, throwOnSet = false } = {}) {
    this.map = new Map();
    this.throwOnGet = throwOnGet;
    this.throwOnSet = throwOnSet;
  }
  getItem(key) {
    if (this.throwOnGet) throw new Error("SecurityError");
    return this.map.has(key) ? this.map.get(key) : null;
  }
  setItem(key, value) {
    if (this.throwOnSet) throw new Error("QuotaExceededError");
    this.map.set(key, String(value));
  }
}

module.exports = { seqRng, validQuestion, fakeQuestions, FakeStorage };
